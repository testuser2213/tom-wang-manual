https://github.com/cmlenz/jquery-iframe-transport/blob/master/jquery.iframe-transport.js

https://github.com/stevepofd/jquery-iframe-utils/blob/master/jquery.iframe-utils.js

https://github.com/house9/jquery-iframe-auto-height/blob/master/release/jquery.iframe-auto-height.plugin.1.5.0.js