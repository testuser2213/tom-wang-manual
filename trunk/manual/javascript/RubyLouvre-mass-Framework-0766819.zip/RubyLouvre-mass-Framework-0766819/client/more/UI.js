/* 
 * UI库参考
 * 
 */
http://d.hatena.ne.jp/sutara_lumpur/20100718/1279420832
jquery.ajaxSuggest.js を公開しました。
//ge 
http://d.hatena.ne.jp/cyokodog/20091212/extable01
IvanK http://lib.ivank.net/index.php?p=download一个基于WEBGL的动画库
http://d.hatena.ne.jp/cyokodog/20101015/exchangeselect01

http://d.hatena.ne.jp/cyokodog/20101101/exresize01

http://d.hatena.ne.jp/cyokodog/20100530/exfitframe01
//jsonp
http://d.hatena.ne.jp/shinichitomita/20060825/1156504036

CSSReg
http://www.businessinfo.co.uk/labs/CSSReg/CSSReg.html
各种REG
http://hackvertor.co.uk/hvurl/2n


 http://guang.com/xihuan
  http://faxianla.com/
http://huaban.com/
http://www.meilishuo.com/goods
http://www.mogujie.com/shopping/
  http://chill.com/
http://pinterest.com/

