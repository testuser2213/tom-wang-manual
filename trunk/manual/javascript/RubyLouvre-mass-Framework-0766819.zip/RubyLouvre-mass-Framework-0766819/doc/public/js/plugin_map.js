$["@modules"]["@plugin_map"] = {
    state:2
}
$.define("plugin_map",function(){
    return {
        "$.fn.placeholder":"plugin/placeholder.html"
    }
})

/*
 *
 http://guang.com/xihuan
  http://faxianla.com/
http://huaban.com/
http://www.meilishuo.com/goods
http://www.mogujie.com/shopping/
  http://chill.com/
http://pinterest.com/
 *
 **/