<?php
include("tphplib.inc.php");
$time_start = microtime(true);

$reqdata = array(
    "cmd=GETFACEFLAG&appname=clubflag&uin=7425176\r\n",
//    "cmd=GETGNUMFLAG&appname=club&qqnumber=7425176&client_ip=" . @$_SERVER['REMOTE_ADDR'] . "\r\n",
);

$sock = new multiSocket();
foreach ($reqdata as $req) {
    $sock->add(TPHP_OIGW_HOST, TPHP_OIGW_PORT, $req);
}

$data = $sock->execute();
print_r($data);

echo "time_used:" . (microtime(true) - $time_start);


/**
 * 使用非阻塞socket方式处理多个网络请求
 */
class multiSocket
{
    private $_reqlist = array();

    /**
     * 添加一个网络请求
     *
     * @param string $host  主机地址
     * @param int $port  主机端口
     * @param string $req   请求字符串
     * @param string $protocol  请求的协议 默认为tcp
     * @param float $timeout  读写数据的超时时间，浮点数，单位秒，默认为2秒。
     *
     * @return int 0
     */
    public function add($host, $port, $req, $protocol = "tcp", $timeout = 2)
    {
        $this->_reqlist[] = array(
            'host' => $host,
            'port' => $port,
            'req' => $req,
            'protocol' => $protocol,
            'timeout' => $timeout,
        );
        return 0;
    }

    /**
     * 创建无阻塞的socket连接
     *
     * @return array socket数组
     * @throws Exception
     */
    private function _connect()
    {
        if (count($this->_reqlist) == 0) {
            throw new Exception("No request wait to be execute.");
        }
        $sockets = array();

        foreach ($this->_reqlist as $index => $req) {
            //建立无阻塞的socket连接
            $sock = stream_socket_client($req['protocol'] . "://" . $req['host'] . ":" . $req['port'],
                $errno, $errstr, null,
                STREAM_CLIENT_ASYNC_CONNECT | STREAM_CLIENT_CONNECT);
            if ($sock === FALSE) {
                throw new Exception("stream_socket_client error. errno $errno; errmsg:$errstr");
            }
            //设置socket数据链接的超时时间
            stream_set_timeout($sock,
                intval($req['timeout']),
                $req['timeout'] - intval($req['timeout']));

            $sockets[$index] = $sock;
        }
        return $sockets;
    }

    /**
     * 对添加的网络请求使用非阻塞的socket一次完成请求。
     * 该方法是阻塞的，方法内部会无阻塞的处理本次添加的所有的socket请求。
     *
     * @return array 响应列表。
     */
    public function execute($timeout = 2)
    {
        $sockets = $this->_connect();
        $base_fd = event_base_new();

        foreach ($sockets as $index => $sock) {

            //以下是对socket的可写事件设置和绑定{{
            //初始化一个事件对象
            $event_fd = event_new();
            //将该事件设置为socket可写时时触发

            //因为soket完成connect以后,一直是可写的，会不停触发EV_WRITE, 所以我们奖EV_WRITE和EV_READ分开处理。
            event_set($event_fd, $sock, EV_WRITE ,
                //回调函数为$this->_eventCallback
                array(&$this, "_eventCallback"),
                //回调的自定义参数中，$event_fd和$base_fd是固定值，同时传入了$index，方便我们索引请求和记录结果
                array($event_fd, $base_fd, $index));

            //将该时间关联到事件base上
            event_base_set($event_fd, $base_fd);

            //开始监听可写事件，设置事件超时时间
            event_add($event_fd, $timeout * 1000000);
            //}}可写事件设置和绑定结束


            //以下是对可读事件进行设置和绑定
            $event_fd = event_new();
            event_set($event_fd, $sock, EV_READ,
                array( &$this, "_eventCallback" ),
                array($event_fd, $base_fd, $index));
            event_base_set($event_fd, $base_fd);
            event_add($event_fd, $timeout*1000000);

        }

        event_base_loop($base_fd);
        $this->_reqlist = array();
        ksort($this->_result);
        return $this->_result;
    }

    private $_result;

    private function _eventCallback($fd, $events, $arg)
    {
        $index = $arg[2];

        if ($events & EV_WRITE) {
            $str_cmd = $this->_reqlist[$arg[2]]['req'];
            $ret = fwrite($fd, $str_cmd);

            if($ret === FALSE){
                throw new Exception("write to server error");
            }
        }

        if ($events & EV_READ) {
            $result = fgets($fd);
            fclose($fd);
            $this->_result[$index] = $result;
        }
    }
}

