<?php
include("tphplib.inc.php");
$time_start= microtime(true);

$reqdata = array(
    "cmd=GETFACEFLAG&appname=clubflag&uin=7425176\r\n",
    "cmd=GETGNUMFLAG&appname=club&qqnumber=7425176&client_ip=" . @$_SERVER['REMOTE_ADDR'] . "\r\n",
);

$sock = new multiSocket();
foreach ($reqdata as $req){
    $sock->add(TPHP_OIGW_HOST,TPHP_OIGW_PORT, $req);
}

$data = $sock->execute();
print_r($data);

echo "time_used:" . (microtime(true) - $time_start);


/**
 * 使用非阻塞socket方式处理多个网络请求
 */
class multiSocket{
    private $_reqlist = array();

    /**
     * 添加一个网络请求
     * @param $host string 主机地址
     * @param $port int 主机端口
     * @param $req string  请求字符串
     * @param $protocol string 请求的协议 默认为tcp
     * @param $timeout float 读写数据的超时时间，浮点数，单位秒，默认为2秒。
     *
     * @return array 请求列表
     */
    public function add($host, $port, $req, $protocol="tcp" , $timeout = 2){
        $this->_reqlist[] = array(
            'host' => $host,
            'port' => $port,
            'req'   => $req,
            'protocol' => $protocol,
            'timeout' => $timeout,
        );
        return 0;
    }

    /**
     * 对添加的网络请求使用非阻塞的socket一次完成请求。
     * 该方法是阻塞的，方法内部会无阻塞的处理本次添加的所有的socket请求。
     *
     * @return array 响应列表。
     */
    public function execute($timeout = 2 ){
        if(count($this->_reqlist) == 0){
            throw new Exception("No request wait to be execute.");
        }
        $result = array();

        foreach($this->_reqlist as $index => $req){
            //建立无阻塞的socket连接
            $sock = stream_socket_client($req['protocol'] . "://" . $req['host'] . ":" . $req['port'],
                                                            $errno, $errstr, null,
                                                            STREAM_CLIENT_ASYNC_CONNECT|STREAM_CLIENT_CONNECT);
            if($sock === FALSE){
                throw new Exception("stream_socket_client error. errno $errno; errmsg:$errstr");
            }
            //设置socket数据链接的超时时间
            stream_set_timeout( $sock,
                                intval($req['timeout']),
                                $req['timeout'] - intval($req['timeout']) );

            $sockets[$index] = $sock;
        }
        $read_all = $write_all = $sockets;
        $time_start = microtime(true);

        //无限循环，直到所有的socket请求都处理完毕，或者超时
        while (count($sockets)) {

            //如果循环的时间超过设置的超时时间，则跳出循环
            if(microtime(true) - $time_start >= $timeout){
                break;
            }

            $read = $read_all;
            $write = $write_all;

            //等待socket流可读或者可写
            $ret = stream_select($read, $write, $except = null, 0, 200000);
            if($ret === FALSE){
                throw new Exception("stream_select error");
            }

            //如果有可读的流，则读取响应
            if(count($read)>0){
                foreach ($read as $r) {
                    $id = array_search($r, $sockets);
                    $data = fgets($r);
                    $result[$id] = $data;
                    fclose($r);
                    unset($sockets[$id]);
                    unset($read_all[$id]);
                }
            }
            //如果有可写入的数据流，则写入请求
            if(count($write)>0){
                foreach ($write as $w) {
                    $id = array_search($w, $sockets);
                    $str_cmd = $this->_reqlist[$id]['req'];
                    fwrite($w, $str_cmd);
                    unset($write_all[$id]);
                }
            }
        }
        $this->_reqlist = array();
        ksort($result);
        return $result;
    }

}

