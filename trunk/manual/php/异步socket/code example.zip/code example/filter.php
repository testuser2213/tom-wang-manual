<?php
/**
 * Example of stream filtering. 
 */
 
// Open two file handles.
//We will begin with the file test.txt.bz2, 
//which is a bzip2-compressed text file whose contents are Hello World.
$in = fopen('test.txt.bz2', 'rb');
$out = fopen('test-uppercase.txt', 'wb');
 
// Add a decode filter to the first.
stream_filter_prepend($in, 'bzip2.decompress', STREAM_FILTER_READ);
 
// Change the charset from ISO-8859-1 to UTF-8
stream_filter_append($out, 'convert.iconv.ISO-8859-1/UTF-8', STREAM_FILTER_WRITE);
 
// Uppercase the entire string.
stream_filter_append($out, 'string.toupper', STREAM_FILTER_WRITE);
 
// Run ROT-13 on the output.
stream_filter_append($out, 'string.rot13', STREAM_FILTER_WRITE);
 
// Now copy. All of the filters are applied here.
stream_copy_to_stream($in, $out);
 
// Clean up.
fclose($in);
fclose($out); //URYYB JBEYQ.
?>